# Please Fork or Star the repo before cloning to your local system

# Quiz-App
A quiz app created with GUI in python using tkinter.

`This quiz app contains question about the programming language Python and has three level of hardness i.e. Easy, Medium and Hard.`

# How to Run.
Download all the files in the same folder.
Then run the quiz.py file.
